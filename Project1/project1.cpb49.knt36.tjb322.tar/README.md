# CS-475-Project-1

./setcookie cpb49 knt36 tjb322

#Inside of the test.bash folder contains a list of how everything should be ran. Running the test bash file with the targets inside of the folder will test them all.
# all targets tested and should be working. 
#Read specific readme for specific solution if problems occur
# if any problem occurs email us. all solutions work.
