#! /usr/bin/python

print "Khoi Tran" + "\x00" + "A+"
